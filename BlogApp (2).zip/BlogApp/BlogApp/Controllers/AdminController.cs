﻿using Microsoft.AspNetCore.Mvc;

namespace BlogApp.Controllers
{
    public class AdminController : Controller
    {
        private const string AdminSessionKey = "IsAdmin";

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (username == "admin" && password == "1234")
            {
                HttpContext.Session.SetString(AdminSessionKey, "true");
                return RedirectToAction("Index");
            }

            ViewBag.Error = "Hatalı giriş";
            return View();
        }

        public IActionResult Index()
        {
            if (!IsAdmin())
                return RedirectToAction("Login");

            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Remove(AdminSessionKey);
            return RedirectToAction("Login");
        }

        private bool IsAdmin()
        {
            return HttpContext.Session.GetString(AdminSessionKey) == "true";
        }
        [HttpGet]
        public IActionResult Gallery()
        {
            var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");

            if (!Directory.Exists(uploadPath))
                Directory.CreateDirectory(uploadPath);

            var images = Directory.GetFiles(uploadPath)
                .Select(Path.GetFileName)
                .ToList();

            return View(images);
        }



        [HttpPost]
        public async Task<IActionResult> Gallery(List<IFormFile> files)
        {
            foreach (var file in files)
            {
                if (file.Length > 0)
                {
                    var fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);
                    var savePath = Path.Combine(Directory.GetCurrentDirectory(),
                        "wwwroot/uploads",
                        fileName);

                    using var stream = new FileStream(savePath, FileMode.Create);
                    await file.CopyToAsync(stream);
                }
            }

            return RedirectToAction("Gallery");
        }

    }
}
