using BlogApp.Models;
using BlogApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace BlogApp.Controllers;

public class BlogController : Controller
{
    private readonly IBlogService _blogService;

    public BlogController(IBlogService blogService)
    {
        _blogService = blogService;
    }

    private bool IsAdmin()
    {
        return HttpContext.Session.GetString("IsAdmin") == "true";
    }

    public IActionResult Index()
    {
        var blogs = _blogService.GetAllBlogs();
        return View(blogs);
    }

    public IActionResult Details(int id)
    {
        var blog = _blogService.GetBlogById(id);
        if (blog == null)
            return NotFound();

        var allComments = blog.Comments ?? new List<Comment>();

        ViewBag.MainComments = allComments
            .Where(c => c.ParentCommentId == null)
            .OrderByDescending(c => c.CreatedDate)
            .ToList();

        ViewBag.Replies = allComments
            .Where(c => c.ParentCommentId != null)
            .GroupBy(c => c.ParentCommentId)
            .ToDictionary(g => g.Key, g => g.ToList());

        ViewBag.CommentViewModel = new CommentViewModel
        {
            BlogId = id
        };

        ViewBag.IsAdmin = IsAdmin();

        return View(blog);
    }
    
    [HttpGet]
    public IActionResult Create()
    {
        if (!IsAdmin())
            return Unauthorized();

        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(BlogViewModel model)
    {
        if (!IsAdmin())
            return Unauthorized();

        if (!ModelState.IsValid)
            return View(model);

        string? imagePath = null;

        if (model.Image != null)
        {
            var extension = Path.GetExtension(model.Image.FileName);
            var newImageName = Guid.NewGuid() + extension;

            var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            var filePath = Path.Combine(uploadsFolder, newImageName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await model.Image.CopyToAsync(stream);
            }

            imagePath = "/uploads/" + newImageName;
        }

        var blog = new Blog
        {
            Title = model.Title,
            Content = model.Content,
            Author = model.Author,
            Type = model.Type,
            Image = imagePath,
            CreatedDate = DateTime.Now
        };

        _blogService.AddBlog(blog);
        return RedirectToAction("Index");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult AddComment(CommentViewModel model)
    {
        if (!ModelState.IsValid)
        {
            var blogInvalid = _blogService.GetBlogById(model.BlogId);
            if (blogInvalid == null)
                return NotFound();

            var allComments = blogInvalid.Comments ?? new List<Comment>();

            ViewBag.MainComments = allComments
                .Where(c => c.ParentCommentId == null)
                .OrderByDescending(c => c.CreatedDate)
                .ToList();

            ViewBag.Replies = allComments
                .Where(c => c.ParentCommentId != null)
                .GroupBy(c => c.ParentCommentId)
                .ToDictionary(g => g.Key, g => g.ToList());

            ViewBag.CommentViewModel = model;
            ViewBag.IsAdmin = IsAdmin();

            return View("Details", blogInvalid);
        }

        var comment = new Comment
        {
            BlogId = model.BlogId,
            Author = model.Author,
            Content = model.Content,
            CreatedDate = DateTime.Now,
            ParentCommentId = model.ParentCommentId
        };

        _blogService.AddComment(comment);

        return RedirectToAction("Details", new { id = model.BlogId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult DeleteComment(int commentId, int blogId)
    {
        if (!IsAdmin())
            return Unauthorized();

        _blogService.DeleteComment(commentId);
        return RedirectToAction("Details", new { id = blogId });
    }
}
