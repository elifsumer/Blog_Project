﻿using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MimeKit;

[ApiController]
[Route("api/[controller]")]
public class MailController : ControllerBase
{
    private readonly SmtpOptions _smtp;

    public MailController(IOptions<SmtpOptions> smtpOptions)
    {
        _smtp = smtpOptions.Value;
    }

    [HttpPost("send")]
    public async Task<IActionResult> Send([FromBody] SendMailRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.To) ||
            string.IsNullOrWhiteSpace(request.Subject) ||
            string.IsNullOrWhiteSpace(request.Body))
        {
            return BadRequest(new { message = "To / Subject / Body zorunlu." });
        }

        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(_smtp.FromName, _smtp.FromEmail));
        message.To.Add(MailboxAddress.Parse(request.To));
        message.Subject = request.Subject;

        message.Body = request.IsHtml
            ? new TextPart("html") { Text = request.Body }
            : new TextPart("plain") { Text = request.Body };

        using var client = new SmtpClient();

        // Sertifika problemi yaşıyorsan geçici olarak açabilirsin (prod’da önerilmez)
        // client.ServerCertificateValidationCallback = (s, c, h, e) => true;

        var secureOpt = _smtp.UseStartTls ? SecureSocketOptions.StartTls : SecureSocketOptions.Auto;

        await client.ConnectAsync(_smtp.Host, _smtp.Port, secureOpt);
        await client.AuthenticateAsync(_smtp.Username, _smtp.Password);
        await client.SendAsync(message);
        await client.DisconnectAsync(true);

        return Ok(new { message = "Mail gönderildi ✅" });
    }
}

public class SmtpOptions
{
    public string Host { get; set; } = string.Empty;
    public int Port { get; set; } = 587;
    public bool UseStartTls { get; set; } = true;
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string FromEmail { get; set; } = string.Empty;
    public string FromName { get; set; } = string.Empty;
}