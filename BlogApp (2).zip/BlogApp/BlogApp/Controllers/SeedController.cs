using BlogApp.Models;
using BlogApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace BlogApp.Controllers;

public class SeedController : Controller
{
    private readonly IBlogService _blogService;

    public SeedController(IBlogService blogService)
    {
        _blogService = blogService;
    }

    public IActionResult Initialize()
    {
        // Örnek blog verileri ekle
        var blog1 = new Blog
        {
            Title = "ASP.NET MVC'ye Giriş",
            Content = "ASP.NET MVC, Microsoft'un web uygulamaları geliştirmek için sunduğu güçlü bir framework'tür. Model-View-Controller mimarisi sayesinde kodunuzu daha organize ve bakımı kolay hale getirir.",
            Author = "Ahmet Yılmaz",
            CreatedDate = DateTime.Now.AddDays(-5)
        };

        var blog2 = new Blog
        {
            Title = "C# ile Nesne Yönelimli Programlama",
            Content = "C# modern ve güçlü bir programlama dilidir. Nesne yönelimli programlama prensipleri ile yazılım geliştirme sürecini kolaylaştırır. Bu yazıda temel OOP kavramlarını ele alacağız.",
            Author = "Mehmet Demir",
            CreatedDate = DateTime.Now.AddDays(-3)
        };

        var blog3 = new Blog
        {
            Title = "Veri Yönetimi ve Dosya İşlemleri",
            Content = "Uygulamalarımızda verileri saklamak ve yönetmek için çeşitli yöntemler kullanabiliriz. Bu yazıda dosya tabanlı veri saklama yöntemlerini inceleyeceğiz.",
            Author = "Ayşe Kaya",
            CreatedDate = DateTime.Now.AddDays(-1)
        };

        _blogService.AddBlog(blog1);
        _blogService.AddBlog(blog2);
        _blogService.AddBlog(blog3);

        return RedirectToAction("Index", "Blog");
    }
}
