using System.ComponentModel.DataAnnotations;

namespace BlogApp.Models;

public class CommentViewModel
{
    [Required(ErrorMessage = "Yazar adı gereklidir")]
    [Display(Name = "Yazar Adı")]
    public string Author { get; set; } = string.Empty;

    [Required(ErrorMessage = "Yorum içeriği gereklidir")]
    [Display(Name = "Yorum")]
    public string Content { get; set; } = string.Empty;

    public int BlogId { get; set; }
    public int? ParentCommentId { get; set; }

}
