using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace BlogApp.Models;

public class BlogViewModel
{
    [Required(ErrorMessage = "Başlık gereklidir")]
    [Display(Name = "Blog Başlığı")]
    public string Title { get; set; } = string.Empty;
    [Required(ErrorMessage = "Blog türü gereklidir")]
    [Display(Name = "Blog Türü")]
    public string Type { get; set; } = string.Empty;
    
    [Required(ErrorMessage = "İçerik gereklidir")]
    [Display(Name = "Blog İçeriği")]
    
    public string Content { get; set; } = string.Empty;

    [Required(ErrorMessage = "Yazar adı gereklidir")]
    [Display(Name = "Yazar Adı")]
    public string Author { get; set; } = string.Empty;
    [Display(Name = "Kapak Görseli")]
    public IFormFile? Image { get; set; }
    public string? ExistingImagePath { get; set; }
}
