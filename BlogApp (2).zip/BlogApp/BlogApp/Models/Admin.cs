﻿namespace BlogApp.Models;

public class Admin
{
    public string Username { get; set; } = "admin";
    public string Password { get; set; } = "1234";
}