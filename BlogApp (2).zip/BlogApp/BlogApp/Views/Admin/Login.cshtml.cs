﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogApp.Views.Admin;

public class Login : PageModel
{
    public void OnGet()
    {
        
    }
}