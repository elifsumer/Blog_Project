using BlogApp.Models;
using System.Text.Json;

namespace BlogApp.Services;

public interface IBlogService
{
    List<Blog> GetAllBlogs();
    Blog? GetBlogById(int id);

    void AddBlog(Blog blog);
    void AddComment(Comment comment);
    void DeleteComment(int commentId);

    void SaveBlogs();
}

public class BlogService : IBlogService
{
    private readonly string _blogsFilePath;
    private readonly string _commentsFilePath;

    private List<Blog> _blogs;
    private List<Comment> _comments;

    public BlogService()
    {
        var dataDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Data");
        if (!Directory.Exists(dataDirectory))
        {
            Directory.CreateDirectory(dataDirectory);
        }

        _blogsFilePath = Path.Combine(dataDirectory, "blogs.txt");
        _commentsFilePath = Path.Combine(dataDirectory, "comments.txt");

        _blogs = LoadBlogs();
        _comments = LoadComments();
        AttachCommentsToBlogs();
    }


    private List<Blog> LoadBlogs()
    {
        if (!File.Exists(_blogsFilePath))
            return new List<Blog>();

        try
        {
            var json = File.ReadAllText(_blogsFilePath);
            return string.IsNullOrWhiteSpace(json)
                ? new List<Blog>()
                : JsonSerializer.Deserialize<List<Blog>>(json) ?? new List<Blog>();
        }
        catch
        {
            return new List<Blog>();
        }
    }

    private List<Comment> LoadComments()
    {
        if (!File.Exists(_commentsFilePath))
            return new List<Comment>();

        try
        {
            var json = File.ReadAllText(_commentsFilePath);
            return string.IsNullOrWhiteSpace(json)
                ? new List<Comment>()
                : JsonSerializer.Deserialize<List<Comment>>(json) ?? new List<Comment>();
        }
        catch
        {
            return new List<Comment>();
        }
    }

    private void AttachCommentsToBlogs()
    {
        foreach (var blog in _blogs)
        {
            blog.Comments = _comments
                .Where(c => c.BlogId == blog.Id)
                .OrderByDescending(c => c.CreatedDate)
                .ToList();
        }
    }


    public List<Blog> GetAllBlogs()
    {
        return _blogs
            .OrderByDescending(b => b.CreatedDate)
            .ToList();
    }

    public Blog? GetBlogById(int id)
    {
        var blog = _blogs.FirstOrDefault(b => b.Id == id);
        if (blog != null)
        {
            blog.Comments = _comments
                .Where(c => c.BlogId == id)
                .OrderByDescending(c => c.CreatedDate)
                .ToList();
        }
        return blog;
    }

    public void AddBlog(Blog blog)
    {
        blog.Id = _blogs.Any() ? _blogs.Max(b => b.Id) + 1 : 1;
        _blogs.Add(blog);
        SaveBlogs();
    }
    

    public void SaveBlogs()
    {
        var options = new JsonSerializerOptions { WriteIndented = true };
        File.WriteAllText(_blogsFilePath, JsonSerializer.Serialize(_blogs, options));
    }

    public void AddComment(Comment comment)
    {
        comment.Id = _comments.Any() ? _comments.Max(c => c.Id) + 1 : 1;
        _comments.Add(comment);
        SaveComments();
    }

    public void DeleteComment(int commentId)
    {
        var comment = _comments.FirstOrDefault(c => c.Id == commentId);
        if (comment == null)
            return;

        var replies = _comments
            .Where(c => c.ParentCommentId == commentId)
            .ToList();

        foreach (var reply in replies)
        {
            _comments.Remove(reply);
        }

        _comments.Remove(comment);
        SaveComments();
    }

    private void SaveComments()
    {
        var options = new JsonSerializerOptions { WriteIndented = true };
        File.WriteAllText(_commentsFilePath, JsonSerializer.Serialize(_comments, options));
    }
}
